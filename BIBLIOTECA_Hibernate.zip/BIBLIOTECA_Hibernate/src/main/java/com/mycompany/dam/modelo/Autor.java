/**
 *
 * @author Rodrigo
 */
package com.mycompany.dam.modelo;


// Importa de todos los paquetes de la biblioteca/librería "persistence".
import javax.persistence.*;
// Importa de todos los paquetes de la biblioteca/librería "LocalDate".
import java.time.LocalDate;
// Importa de todos los paquetes de la biblioteca/librería "ArrayList".
import java.util.ArrayList;
// Importa de todos los paquetes de la biblioteca/librería "List".
import java.util.List;

// Definimos una entidad que representará a un autor de libros en la biblioteca.
    /*
     * Primero mapea a la tabla "autores" en la base de datos.
     * Despues define una relación donde/en a que un autor puede escribir múltiples libros, es decir: (1:N).
     */
@Entity
@Table(name = "autores")
public class Autor{
    // ==================== ATRIBUTOS ====================
        // Declara las variables, atributos.
            // Sustituye al archivo "Departamento.hbm.xml".
                /*
                 * Se genera el identificador, "ID", único (clave primaria) de "autor".
                 * Se genera automáticamente mediante estrategia "IDENTITY".
                 * Lo 'anclamos' a la columna de nombre "id_autor".
                 */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_autor")
    private Integer idAutor;
    
                /*
                 * Atributo para el nombre del autor
                 * Lo 'anclamos' a la columna de nombre "nombre",añadiéndole atributos de campo obligatorio ("nullable") y de máximo 100 caracteres ("length").
                 */
    @Column(name = "nombre", nullable = false, length = 100)
    private String nombre;
    
                /*
                 * Atributo para los apellidos del autor
                 * Lo 'anclamos' a la columna de nombre "apellidos",añadiéndole atributos de campo obligatorio ("nullable") y de máximo 100 caracteres ("length").
                 */
    @Column(name = "apellidos", nullable = false, length = 100)
    private String apellidos;
    
                /*
                 * Atributo para la nacionalidad del autor
                 * Lo 'anclamos' a la columna de nombre "nacionalidad",añadiéndole el atributo de máximo 50 caracteres ("length").
                 * Al no anclar a la columna "nacionalidad" el atributo "nullable" el campo queda opcional, en vez de obligatorio.
                 */
    @Column(name = "nacionalidad", length = 50)
    private String nacionalidad;
    
                /*
                 * Atributo para la nacionalidad del autor
                 * Lo 'anclamos' a la columna de nombre "fecha_nacimiento"
                 * Al no anclar a la columna "fecha_nacimiento" los atributos "nullable" y "length" el campo queda opcional, en vez de obligatorio; y sin un límite máximo de caracteres.
                 */
    @Column(name = "fecha_nacimiento")
    private LocalDate fechaNacimiento;
    
    
    // ==================== RELACIONES ====================
        /*
         * Hacemos una relación para la lista de libros escritos por el autor. Es decir, una relación entre la lista de libros, los libros, y el autor que los escribió.
         * 
         * Hacemos una relación (1:N) bidireccional con "Libro".
         *   El atributo "  mappedBy = "autor"           " indica que "Libro" es el propietario de la relación.
         *   El atributo "  cascade = CascadeType.ALL    " refire a que todas las operaciones se propagan a los libros.
         *   El atributo "  orphanRemoval = true         " elimina automáticamente libros huérfanos.
         *   El atributo "  fetch = FetchType.LAZY       " hace/aplica una carga perezosa para optimizar rendimiento.
         * 
         * Definimos la cascada aplicada ("cascade = CascadeType.ALL").
         *   El atributo "  PERSIST " Aplica que al guardar un autor, guarda sus libros.
         *   El atributo "  MERGE   " Aplica que al actualizar un autor, actualiza sus libros.
         *   El atributo "  REMOVE  " Aplica que al eliminar un autor, elimina sus libros.
         *   El atributo "  REFRESH " Aplica que al refrescar un autor, refresca sus libros.
         *   El atributo "  DETACH  " Aplica que al desasociar un autor, desasocia sus libros.
         */
    @OneToMany(mappedBy = "autor", 
               cascade = CascadeType.ALL, 
               orphanRemoval = true, 
               fetch = FetchType.LAZY)
    private List<Libro> libros = new ArrayList<>();
    
    
    // ==================== CONSTRUCTORES ====================
        // Crea el constructor vacío, sin parámetros. Es necesario para que "JPA" pueda crear las instancias.
    public Autor(){}
    
        // Crea el constructor de/para las variables, con todos los campos excepto el "ID" y relaciones.
            /*
             * @param nombre Nombre del autor
             * @param apellidos Apellidos del autor
             * @param nacionalidad Nacionalidad del autor
             * @param fechaNacimiento Fecha de nacimiento del autor
             */
    public Autor(String nombre, String apellidos, String nacionalidad, LocalDate fechaNacimiento){
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.nacionalidad = nacionalidad;
        this.fechaNacimiento = fechaNacimiento;
    }
    
    // ==================== MÉTODOS HELPER ====================
    
    /**
     * Añade un libro al autor manteniendo la consistencia bidireccional.
     * 
     * Este método es FUNDAMENTAL para mantener la integridad de la relación:
     * 1. Añade el libro a la lista de libros del autor
     * 2. Establece el autor en el libro (lado opuesto de la relación)
     * 
     * Ejemplo de uso:
     * <pre>
     * Autor autor = new Autor("Gabriel", "García Márquez", "Colombiana", ...);
     * Libro libro = new Libro("Cien años de soledad", "978-84-376-0494-7", ...);
     * autor.addLibro(libro); // Mantiene consistencia en ambos lados
     * </pre>
     * 
     * @param libro Libro a añadir al autor
     */
    public void addLibro(Libro libro) {
        libros.add(libro);
        libro.setAutor(this);
    }
    
    /**
     * Elimina un libro del autor manteniendo la consistencia bidireccional.
     * 
     * Este método es FUNDAMENTAL para mantener la integridad de la relación:
     * 1. Elimina el libro de la lista de libros del autor
     * 2. Elimina la referencia del autor en el libro (lado opuesto)
     * 
     * Si orphanRemoval = true está activado (como en este caso), 
     * el libro será eliminado de la base de datos automáticamente.
     * 
     * Ejemplo de uso:
     * <pre>
     * Libro libro = autor.getLibros().get(0);
     * autor.removeLibro(libro); // El libro será eliminado de la BD
     * </pre>
     * 
     * @param libro Libro a eliminar del autor
     */
    public void removeLibro(Libro libro) {
        libros.remove(libro);
        libro.setAutor(null);
    }
    
    // ==================== GETTERS Y SETTERS ====================
    
    /**
     * Obtiene el ID del autor.
     * @return ID del autor
     */
    public Integer getIdAutor() {
        return idAutor;
    }
    
    /**
     * Establece el ID del autor.
     * Generalmente no se usa directamente ya que el ID es autogenerado.
     * @param idAutor ID del autor
     */
    public void setIdAutor(Integer idAutor) {
        this.idAutor = idAutor;
    }
    
    /**
     * Obtiene el nombre del autor.
     * @return Nombre del autor
     */
    public String getNombre() {
        return nombre;
    }
    
    /**
     * Establece el nombre del autor.
     * @param nombre Nombre del autor
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    /**
     * Obtiene los apellidos del autor.
     * @return Apellidos del autor
     */
    public String getApellidos() {
        return apellidos;
    }
    
    /**
     * Establece los apellidos del autor.
     * @param apellidos Apellidos del autor
     */
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }
    
    /**
     * Obtiene la nacionalidad del autor.
     * @return Nacionalidad del autor
     */
    public String getNacionalidad() {
        return nacionalidad;
    }
    
    /**
     * Establece la nacionalidad del autor.
     * @param nacionalidad Nacionalidad del autor
     */
    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }
    
    /**
     * Obtiene la fecha de nacimiento del autor.
     * @return Fecha de nacimiento del autor
     */
    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }
    
    /**
     * Establece la fecha de nacimiento del autor.
     * @param fechaNacimiento Fecha de nacimiento del autor
     */
    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }
    
    /**
     * Obtiene la lista de libros del autor.
     * 
     * IMPORTANTE: Si se accede fuera de una sesión de Hibernate y 
     * la carga es LAZY, puede lanzar LazyInitializationException.
     * 
     * @return Lista de libros del autor
     */
    public List<Libro> getLibros() {
        return libros;
    }
    
    /**
     * Establece la lista de libros del autor.
     * 
     * ATENCIÓN: Preferible usar addLibro() y removeLibro() para 
     * mantener la consistencia bidireccional automáticamente.
     * 
     * @param libros Lista de libros del autor
     */
    public void setLibros(List<Libro> libros) {
        this.libros = libros;
    }
    
    // ==================== MÉTODOS OBJECT ====================
    
    /**
     * Representación en String del autor.
     * Muestra información relevante sin cargar todas las relaciones.
     * 
     * @return Cadena con la información del autor
     */
    @Override
    public String toString() {
        return "Autor{" +
                "idAutor=" + idAutor +
                ", nombre='" + nombre + '\'' +
                ", apellidos='" + apellidos + '\'' +
                ", nacionalidad='" + nacionalidad + '\'' +
                ", fechaNacimiento=" + fechaNacimiento +
                ", número de libros=" + libros.size() +
                '}';
    }
    
    /**
     * Compara dos autores por igualdad.
     * Dos autores son iguales si tienen el mismo ID.
     * 
     * @param o Objeto a comparar
     * @return true si son iguales, false en caso contrario
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Autor autor = (Autor) o;
        return idAutor != null && idAutor.equals(autor.idAutor);
    }
    
    /**
     * Calcula el código hash del autor basado en su ID.
     * 
     * @return Código hash del autor
     */
    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
}