/**
 *
 * @author Rodrigo
 */
package com.mycompany.dam.modelo;



public class Libro{
    
}