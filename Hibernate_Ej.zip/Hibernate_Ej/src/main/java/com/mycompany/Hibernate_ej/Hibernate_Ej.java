/**
 *
 * @author Rodrigo
 */
package com.mycompany.Hibernate_ej;


// Importa del paquete java "Hibernate_ej.modelo" el archivo "Departamento".
import com.mycompany.Hibernate_ej.modelo.Departamento;
// Importa del paquete java "Hibernate_ej.modelo" el archivo "Empleado".
import com.mycompany.Hibernate_ej.modelo.Empleado;
// Importa de la biblioteca/librería el paquete "List".
import java.util.List;
// Importa de la biblioteca/librería el paquete "JOptionPane".
import javax.swing.JOptionPane;
// Importa de la biblioteca/librería el paquete "HibernateException".
import org.hibernate.HibernateException;
// Importa de la biblioteca/librería el paquete "Session".
import org.hibernate.Session;
// Importa de la biblioteca/librería el paquete "Transaction".
import org.hibernate.Transaction;
// Importa de la biblioteca/librería el paquete "Query".
import org.hibernate.query.Query;

public class Hibernate_Ej{
    public static void main(String[] args){
        System.out.println("Inicializando la aplicación de Hibernate...");
        
        // Llama/Inicializa el método "crearDepartamentoEmpleado". (Crea nuevos objetos para/en la base de datos)
        crearDepartamentoEmpleado();
        
        // Llama/Inicializa el método "leerDepartamentos" y "leerEmpleados". (Leen los archivos)
        leerDepartamentos();
        leerEmpleados();
        
        // Llama/Inicializa el método "leerDepartamentos". (Modifica un empleado)
        actualizarSalario(5, 10000);
        
        // Llama/Inicializa el método "eliminarEmpleado". (Elimina/Borra una fila de la tabla "Empleado")
        eliminarEmpleado(5);
        eliminarDepartamento(1);
    }
    
    public static void leerDepartamentos(){
        Session session = null;
        
        try{
            session = HibernateUtil.getSessionFactory().openSession();
            
            // Operación CRUD.
            Query<Departamento> query = session.createQuery("FROM Departamento", Departamento.class);
            List<Departamento> departamentos = query.list();
            
            System.out.println("\n\n\t<==================== LISTA de DEPARTAMENTOS ====================>\n\n");
            for (Departamento departamento : departamentos){
                System.out.println(departamento);
            }
        } catch (HibernateException Hex){
            JOptionPane.showMessageDialog(null, "Error de sesiones", "'Session Factory' creation failed / La fabricación de sesiones ha fallado: " + Hex.getMessage(), JOptionPane.ERROR_MESSAGE);
        } finally{
            if (session != null && session.isOpen()){ session.close(); }
        }
    }
    
    public static void crearDepartamentoEmpleado(){
        Session session = null;
        Transaction tx = null;
        
        try{
            session = HibernateUtil.getSessionFactory().openSession();
            
            // Operaciones CRUD
            tx = session.beginTransaction();
            
            // Operaciones CRUD
            Departamento departamento = new Departamento();
            departamento.setNombre("Management");
            session.save(departamento);
            
            // Operaciones CRUD
            Empleado empleado = new Empleado();
            empleado.setPrimerNombre("Rodrigo");
            empleado.setSalario(5000);
            empleado.setDepartamento(departamento);
            session.save(empleado);
            
            tx.commit();
            
            System.out.println("\n\tLos nuevos objetos han sido insertados en la base de datos correctamente:\n\t\tDepartamento: " + departamento + "\n\t\tEmpleado: " + empleado);
        } catch (HibernateException Hex){
            JOptionPane.showMessageDialog(null, "Error de lectura", "Error inesperado al leer las tablas sobre la base de datos: " + Hex.getMessage(), JOptionPane.ERROR_MESSAGE);
            if (tx != null) tx.rollback(); // "Rollback" para regresar al úlimo cuardado.
        } finally{
            if (session != null && session.isOpen()){ session.close(); }
        }
    }
    
    public static void leerEmpleados(){
        Session session = null;
        
        try{
            session = HibernateUtil.getSessionFactory().openSession();
            
            // Operación CRUD.
            Query<Empleado> query = session.createQuery("FROM Empleado", Empleado.class);
            List<Empleado> empleados = query.list();
            
            System.out.println("\n\n\t<==================== LISTA de Empelados ====================>\n\n");
            for (Empleado empleado : empleados){
                System.out.println(empleado);
            }
        } catch (HibernateException Hex){
            JOptionPane.showMessageDialog(null, "Error de sesiones", "'Session Factory' creation failed / La fabricación de sesiones ha fallado: " + Hex.getMessage(), JOptionPane.ERROR_MESSAGE);
        } finally{
            if (session != null && session.isOpen()){ session.close(); }
        }
    }
    
    public static void actualizarSalario(long id, double nuevoSalario){
        Session session = null;
        Transaction tx = null;
        
        try{
            session = HibernateUtil.getSessionFactory().openSession();
            
            // Operaciones CRUD
            tx = session.beginTransaction();
            
            Empleado empleado = session.get(Empleado.class, id);
            
            if (empleado != null){
                double salarioAnterior = empleado.getSalario();
                empleado.setSalario(nuevoSalario);
                session.update(empleado);
                
                tx.commit();
                
                System.out.println("El salario del empleado {" + empleado.getPrimerNombre() + "} ha sido actualizado correctamente: " + salarioAnterior + "€ → " + nuevoSalario + "€");
            }
        } catch (HibernateException Hex){
            JOptionPane.showMessageDialog(null, "Error de actualización", "Error inesperado al actualizar los atributos del objeto empleado: " + Hex.getMessage(), JOptionPane.ERROR_MESSAGE);
            if (tx != null) tx.rollback(); // "Rollback" para regresar al úlimo cuardado.
        } finally{
            if (session != null && session.isOpen()){ session.close(); }
        }
    }
    
    public static void eliminarEmpleado(long id){
        Session session = null;
        Transaction tx = null;
        
        Empleado empleado = null; /* Esto lo pongo yo para que pueda ponerlo en el catch. */
        
        try{
            session = HibernateUtil.getSessionFactory().openSession();
            
            // Operaciones CRUD
            tx = session.beginTransaction();
            
            empleado = session.get(Empleado.class, id);
            
            if (empleado != null){
                session.delete(empleado);
                
                tx.commit();
                
                System.out.println("El empleado {" + empleado.getPrimerNombre() + "} ha sido eliminado/borrado de los registro de la base de datos correctamente");
            }
        } catch (HibernateException Hex){
            JOptionPane.showMessageDialog(null, "Error de borrado", "Error inesperado al eliminar/borrar el empleado {" + empleado.getPrimerNombre() + "} de los registro de la base de datos: " + Hex.getMessage(), JOptionPane.ERROR_MESSAGE);
            if (tx != null) tx.rollback(); // "Rollback" para regresar al úlimo cuardado.
        } finally{
            if (session != null && session.isOpen()){ session.close(); }
        }
    }
    
    public static void eliminarDepartamento(long id){
        Session session = null;
        Transaction tx = null;
        
        Departamento departamento = null; /* Esto lo pongo yo para que pueda ponerlo en el catch. */
        
        try{
            session = HibernateUtil.getSessionFactory().openSession();
            
            // Operaciones CRUD
            tx = session.beginTransaction();
            
            departamento = session.get(Departamento.class, id);
            
            if (departamento != null){
                session.delete(departamento);
                
                tx.commit();
                
                System.out.println("El departamento {" + departamento.getNombre()+ "} ha sido eliminado/borrado de los registro de la base de datos correctamente");
            }
        } catch (HibernateException Hex){
            JOptionPane.showMessageDialog(null, "Error de borrado", "Error inesperado al eliminar/borrar el departamento {" + departamento.getNombre() + "} de los registro de la base de datos: " + Hex.getMessage(), JOptionPane.ERROR_MESSAGE);
            if (tx != null) tx.rollback(); // "Rollback" para regresar al úlimo cuardado.
        } finally{
            if (session != null && session.isOpen()){ session.close(); }
        }
    }
}